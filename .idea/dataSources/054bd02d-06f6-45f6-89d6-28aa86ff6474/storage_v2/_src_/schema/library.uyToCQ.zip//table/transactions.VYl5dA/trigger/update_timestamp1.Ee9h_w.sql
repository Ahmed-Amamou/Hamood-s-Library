create definer = root@localhost trigger update_timestamp1
    before update
    on transactions
    for each row
    set new.updated_at = now();

