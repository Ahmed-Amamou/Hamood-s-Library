create definer = root@localhost trigger update_timestamp2
    before update
    on reader
    for each row
    set new.updated_at = now();

