create definer = root@localhost trigger update_timestamp3
    before update
    on book
    for each row
    set new.updated_at = now();

